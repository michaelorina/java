public class patient {
    String name;
    String county;
    String id;

    patient(String Aname, String Acounty, String Anid){
        name = Aname;
        county = Acounty;
        id = Anid;
    }
}
